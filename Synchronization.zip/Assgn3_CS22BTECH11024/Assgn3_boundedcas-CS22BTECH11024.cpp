#include <iostream>
#include <fstream>
#include <chrono>
#include <vector>
#include <atomic>
#include <pthread.h>

using namespace std;

struct ThreadData
{
    int **matrix;
    int num_rows;
    int row_increment;
    int **result_matrix;
};

atomic<int> counter(0);

void *matrixSquare(void *arg)
{
    struct ThreadData *thread_data = (struct ThreadData *)arg;
    int N = thread_data->num_rows;
    int **input_matrix = thread_data->matrix;
    int **result_matrix = thread_data->result_matrix;
    int row_increment = thread_data->row_increment;
    int temp = 0;

    do
    {
        temp = counter.load();
        if (temp >= N)
        {
            break;
        }
        if (counter.compare_exchange_strong(temp, temp + row_increment))
        {
            for (int i = temp; i < min(temp + row_increment, N); i++)
            {
                for (int j = 0; j < N; j++)
                {
                    int sum = 0;
                    for (int k = 0; k < N; k++)
                    {
                        sum += input_matrix[i][k] * input_matrix[k][j];
                    }
                    result_matrix[i][j] = sum;
                }
            }
        }
    } while (true);

    return nullptr;
}

int main()
{
    chrono::high_resolution_clock::time_point start = chrono::high_resolution_clock::now();
    int N, K, row_increment;
    ifstream infile("inp.txt");
    infile >> N >> K >> row_increment;

    int **input_matrix = new int *[N];
    int **result_matrix = new int *[N];

    for (int i = 0; i < N; i++)
    {
        input_matrix[i] = new int[N];
        result_matrix[i] = new int[N];
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            infile >> input_matrix[i][j];
        }
    }
    infile.close();

    pthread_t threads[K];
    struct ThreadData thread_data[K];

    for (int i = 0; i < K; i++)
    {
        thread_data[i].matrix = input_matrix;
        thread_data[i].num_rows = N;
        thread_data[i].row_increment = row_increment;
        thread_data[i].result_matrix = result_matrix;
        pthread_create(&threads[i], NULL, matrixSquare, (void *)&thread_data[i]);
    }

    for (int i = 0; i < K; i++)
    {
        pthread_join(threads[i], NULL);
    }

    chrono::high_resolution_clock::time_point stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    ofstream outfile("out.txt");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            outfile << result_matrix[i][j] << " ";
        }
        outfile << endl;
    }

    for (int i = 0; i < N; i++)
    {
        delete[] input_matrix[i];
        delete[] result_matrix[i];
    }
    delete[] input_matrix;
    delete[] result_matrix;

    outfile << "Time taken: " << duration.count() << " microseconds" << endl;
    outfile.close();

    return 0;
}

