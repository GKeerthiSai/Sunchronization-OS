Name     :-G Sai Keerthi
Roll no  :-CS22BTECH11024
Course   :-Operating Systems
File type:-ReadMe

Please ensure that C++ compiler is installed on your system.

Step-1:Input file
	Create some random input file with name "inp.txt", which includes N, K values along with input matrix.
	Ensure that input file should not be empty and it should be in the same directory as source code.
	Save the source code and go to terminal.

Step-2:Compilation
	Compile the program using the command "g++ file_name.cpp".

Step-3:Execution
	Execute the program using command "./a.out" in the terminal.
	
Note:-
	The code ahev been submitted in 4 different files for 4 different algorithms. 
	1. Assgn3_tas-CS22BTECH11024.cpp        --> for Test-And-Set(TAS) method.
	2. Assgn3_cas-CS22BTECH11024.cpp        --> for Compare-and-Swap(CAS) method.
	3. Assgn3_boundedcas-CS22BTECH11024.cpp --> for bounded Compare-and-Swap(CAS) method.
	4. Assgn3_atomic-CS22BTECH11024.cpp     --> for atomic increment method.
	
	So everytime we need to compile the program as Assgn2_"method"-CS22BTECH11024.cpp in terminal and for every program an ouput file named "out.txt" will be generated.
	And the values after multiplication along with the exectution times will be printed in output file.
		
