#include <iostream>
#include <fstream>
#include <chrono>
#include <vector>
#include <atomic>
#include <pthread.h>

using namespace std;

struct ThreadData
{
    int **matrix;
    int rows_total;
    int rowInc;
    int **outmatrix;
};

atomic<int> counter(0);

void *matrixSquare(void *arg)
{
    struct ThreadData *thread_data = (struct ThreadData *)arg;
    int N = thread_data->rows_total;
    int **inmatrix = thread_data->matrix;
    int **outmatrix = thread_data->outmatrix;
    int rowInc = thread_data->rowInc;

    int temp = 0;

    do
    {
        temp = counter++;
        if (temp >= N)
        {
            break;
        }

        for (int i = temp; i < min(temp + rowInc, N); i++)
        {
            for (int j = 0; j < N; j++)
            {
                int sum = 0;
                for (int k = 0; k < N; k++)
                {
                    sum += inmatrix[i][k] * inmatrix[k][j];
                }
                outmatrix[i][j] = sum;
            }
        }
    } while (true);

    return nullptr;
}

int main()
{
    chrono::high_resolution_clock::time_point start = chrono::high_resolution_clock::now();
    int N, K, rowInc;
    ifstream infile("inp.txt");
    infile >> N >> K >> rowInc;

    int **inmatrix = new int *[N];
    int **outmatrix = new int *[N];

    for (int i = 0; i < N; i++)
    {
        inmatrix[i] = new int[N];
        outmatrix[i] = new int[N];
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            infile >> inmatrix[i][j];
        }
    }
    infile.close();

    pthread_t threads[K];
    struct ThreadData thread_data[K];

    for (int i = 0; i < K; i++)
    {
        thread_data[i].matrix = inmatrix;
        thread_data[i].rows_total = N;
        thread_data[i].rowInc = rowInc;
        thread_data[i].outmatrix = outmatrix;
        pthread_create(&threads[i], NULL, matrixSquare, (void *)&thread_data[i]);
    }

    for (int i = 0; i < K; i++)
    {
        pthread_join(threads[i], NULL);
    }

    chrono::high_resolution_clock::time_point stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    ofstream outfile("out.txt");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            outfile << outmatrix[i][j] << " ";
        }
        outfile << endl;
    }

    for (int i = 0; i < N; i++)
    {
        delete[] inmatrix[i];
        delete[] outmatrix[i];
    }
    delete[] inmatrix;
    delete[] outmatrix;

    outfile << "Time taken: " << duration.count() << " microseconds" << endl;
    outfile.close();

    return 0;
}

